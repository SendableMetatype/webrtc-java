/*
 * Copyright 2019 Alex Andres
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package dev.kastle.webrtc;

/**
 * Describes the current state of the ICE agent and its connection to the ICE
 * server (that is, the STUN or TURN server).
 *
 * @author Alex Andres
 */
public enum RTCIceConnectionState {

	/**
	 * None of the previous states apply and all RTCIceTransports are in the
	 * "NEW" or "CLOSED" state, or there are no transports.
	 */
	NEW,

	/**
	 * None of the previous states apply and any RTCIceTransports are in the
	 * "NEW" or "CHECKING" state.
	 */
	CHECKING,

	/**
	 * None of the previous states apply and all RTCIceTransports are in the
	 * "CONNECTED", "COMPLETED" or "CLOSED" state.
	 */
	CONNECTED,

	/**
	 * None of the previous states apply and all RTCIceTransports are in the
	 * "COMPLETED" or "CLOSED" state.
	 */
	COMPLETED,

	/**
	 * The previous state doesn't apply and any RTCIceTransports are in the
	 * "FAILED" state.
	 */
	FAILED,

	/**
	 * None of the previous states apply and any RTCIceTransports are in the
	 * "DISCONNECTED" state.
	 */
	DISCONNECTED,

	/**
	 * The RTCPeerConnection is closed.
	 */
	CLOSED;

}
